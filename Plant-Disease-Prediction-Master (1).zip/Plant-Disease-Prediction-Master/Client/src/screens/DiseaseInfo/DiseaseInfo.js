import { Box, Heading, Image } from "@chakra-ui/react";
import React from "react";
import { Container } from "@chakra-ui/react";
import "./DiseaseInfo.css";

export default function DiseaseInfo() {
  return (
    <Container maxW="7xl">
      <div className="diseaseContainer">
        <div className="diseaseImage"></div>
        <div className="diseaseImage"> loremadsssssore</div>
        <div className="diseaseImage"></div>
        <div className="diseaseImage"></div>
        <div className="diseaseImage"></div>
        <div className="diseaseImage"></div>
        <div className="diseaseImage"></div>
        <div className="diseaseImage"></div>
      </div>
    </Container>
  );
}
